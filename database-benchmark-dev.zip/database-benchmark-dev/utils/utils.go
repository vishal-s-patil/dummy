package utils

import (
	"bufio"
	"database/sql"
	"encoding/json"
	"fmt"
	"math/rand"
	"os"
	"reflect"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)


func Retrive_query(filename string, idQueryMap map[int]string, required *[]int) {
	if filename == "" {
		fmt.Println("file name is empty")
		return
	}
	sort.Ints(*required)
	file, err := os.Open("queries/" + filename)

	if err != nil {
		fmt.Println("Error opening file:", err)
		return
	}

	defer file.Close()

	scanner := bufio.NewScanner(file)

	if len(*required) == 0 {

		for scanner.Scan() {
			line := scanner.Text()
			id, query := ParseLine(line)
			if id != 0 {
				idQueryMap[id] = query
				*required = append(*required, id)
			}
		}

		if err := scanner.Err(); err != nil {
			fmt.Println("Error reading file:", err)
		}

	} else {
		i := 0
		for scanner.Scan() {
			line := scanner.Text()
			id, query := ParseLine(line)
			if i >= len(*required) {
				break
			}
			if id != (*required)[i] {
				continue
			} else {
				if id != 0 {
					idQueryMap[id] = query
				}
				i++
			}
		}
	}

	// for id, query := range idQueryMap {
	// 	fmt.Printf("%d, %s\n\n\n\n\n", id, query)
	// }
}


func ParseLine(line string) (int, string) {
	parts := strings.SplitN(line, "~", 2)
	if len(parts) != 2 {
		return 0, ""
	}

	id, err := strconv.Atoi(parts[0])
	if err != nil {
		return 0, ""
	}

	// query := strings.Trim(parts[1], `"`)

	return id, parts[1]
}


func GetMapKeys(inputMap map[int]string) []int {
	keys := make([]int, 0, len(inputMap))
	for key := range inputMap {
		keys = append(keys, key)
	}
	return keys
}


func ArgsToMap(args []string) map[string]string {
	keyValuePairs := make(map[string]string)

	// Parse key-value pairs
	for _, arg := range args {
		parts := strings.SplitN(arg, "=", 2)
		if len(parts) == 2 {
			keyValuePairs[parts[0]] = parts[1]
		} else {
			fmt.Printf("Invalid argument: %s\n", arg)
		}
	}

	return keyValuePairs
}


func Stringify_json(mp map[string]interface{}) string {
	jsonData, err := json.Marshal(mp)
	if err != nil {
		fmt.Println("Error:", err)
	}
	return string(jsonData)
}


func IntegersToString(intArray []int, separator string) string {
	stringArray := make([]string, len(intArray))
	for i, v := range intArray {
		stringArray[i] = strconv.Itoa(v)
	}

	resultString := strings.Join(stringArray, separator)
	return resultString
}


func ParseArray(input string) []int {
	input = strings.Trim(input, "[]")

	elements := strings.Split(input, ",")

	var result []int
	for _, element := range elements {
		value, err := strconv.Atoi(strings.TrimSpace(element))
		if err != nil {
			fmt.Printf("Error in utils.ParseArray: %s\n", err)
		}
		result = append(result, value)
	}
	return result
}


func SumOfArr(arr []int) int {
	sum := 0
	for _, v := range arr {
		sum += v
	}
	return sum
}


func GetType(v interface{}) string {
	return reflect.TypeOf(v).String()
}


func ParseIDs(idsStr string) ([]int, error) {
	if idsStr == "all" || idsStr == "" {
		return []int{}, nil
	}

	idStrings := strings.Split(idsStr, ",")

	var ids []int

	for _, idStr := range idStrings {
		id, err := strconv.Atoi(strings.TrimSpace(idStr))
		if err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	return ids, nil
}


type Column struct {
	Name         string
	DBType       string
	GoEquivalent string
	Nullable     bool
}


func GenerateInsertStatement(tableName string, columns []Column) string {
	// r := rand.New(rand.NewSource(10))

	var columnNames, values []string

	// Iterate over each set of columns
	for _, col := range columns {
		// Include only non-nullable columns and 50% of nullable columns
		if !col.Nullable || (col.Nullable && rand.Float32() < 0.5) {
			// fmt.Println("prubted : ", col)
			columnNames = append(columnNames, col.Name)

			// Generate random data based on the data type
			generated_value := generateRandomData(col.GoEquivalent)
			if generated_value != nil {
				stringValue, ok := generated_value.(string)
				if !ok {
					fmt.Println("Conversion to string failed")
					return ""
				}
				values = append(values, stringValue)
			}
		}

	}
	// Construct the INSERT statement
	insertStatement := fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s);", tableName, strings.Join(columnNames, ", "), strings.Join(values, ", "))
	return insertStatement
}


func generateRandomData(goType string) interface{} {
	// Seed the random number generator
	r := rand.New(rand.NewSource(rand.Int63()))

	switch goType {
	case "int":
		return fmt.Sprintf("%d", r.Intn(100))
	case "string":
		// Generate a random string of length 10
		var letterRunes = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
		b := make([]rune, 10)
		for i := range b {
			b[i] = letterRunes[r.Intn(len(letterRunes))]
		}
		return fmt.Sprintf("'%s'", string(b))
		// Add more cases for other data types as needed
	case "time.Time":
		return fmt.Sprintf("'%s'", time.Now().Format("2006-01-02 15:04:05"))
	case "date":
		return fmt.Sprintf("'%s'", time.Now().Format("2006-01-02"))
	default:
		return ""
	}
}


func GetCreateTableStatement(filePath string) string {
	file, err := os.Open(filePath)
	if err != nil {
		fmt.Println("Error opening file:", err)
		return ""
	}
	defer file.Close()

	var createTableStatement string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		createTableStatement += scanner.Text() + "\n"
	}

	if err := scanner.Err(); err != nil {
		fmt.Println("Error reading file:", err)
		return ""
	}

	return createTableStatement
}


func ExtractTableName(createTableStatement string) string {
	// Regular expression pattern to match the table name
	// This assumes that the table name appears after the CREATE TABLE keywords and before the opening parenthesis
	pattern := `CREATE\s+TABLE\s+(\S+)\s*\(`

	// Compile the regular expression
	re := regexp.MustCompile(pattern)

	matches := re.FindStringSubmatch(createTableStatement)

	// If there are no matches, return an empty string
	if len(matches) < 2 {
		return ""
	}

	// Return the table name (the first capturing group)
	return matches[1]
}


func ParseCreateTableStatement(sql string) []Column {
	var columns []Column

	lines := strings.Split(sql, "\n")
	for _, line := range lines {
		// Skip empty lines and lines starting with CREATE TABLE
		if strings.TrimSpace(line) == "" || strings.HasPrefix(strings.TrimSpace(line), "CREATE TABLE") {
			continue
		}

		re := regexp.MustCompile(`\s*(\w+)\s+(\w+)(?:\((\d+)\))?(?:\s+NOT\s+NULL)?`)
		match := re.FindStringSubmatch(line)
		if len(match) < 2 {
			continue
		}

		name := match[1]
		dataType := strings.ToLower(match[2])
		nullable := !strings.Contains(strings.ToUpper(line), "NOT NULL")

		goType := mapSQLTypeToGo(dataType)

		columns = append(columns, Column{
			Name:         name,
			DBType:       dataType,
			GoEquivalent: goType,
			Nullable:     nullable,
		})
	}
	return columns
}


func mapSQLTypeToGo(sqlType string) string {
	switch sqlType {
	case "int", "integer", "smallint", "bigint":
		return "int"
	case "varchar", "char", "text":
		return "string"
	case "float", "real", "double precision":
		return "float64"
	case "timestamp":
		return "time.Time"
	case "date":
		return "date"
	default:
		return "interface{}"
	}
}


func Insert_into_channel(file_name string, ch chan string) {
	file, err := os.Open(file_name)
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		fileName := scanner.Text()
		ch <- fileName
	}
}


func GetMaxEpoch_ts(q string, db *sql.DB) time.Time {
	var maxEpoch interface{}
	var t time.Time
	err := db.QueryRow(q).Scan(&maxEpoch)
	if err != nil {
		fmt.Println("Error executing query1:", err)
		return t
	}
	if maxEpoch == nil {
		return t
	}

	if val, ok := maxEpoch.(time.Time); ok {
		return val
	} else {
		fmt.Println("Interface value is not an time.Time")
		return t
	}
}


func GetMaxEpoch(q string, db *sql.DB) int {
	var maxEpoch interface{}
	err := db.QueryRow(q).Scan(&maxEpoch)
	if err != nil {
		fmt.Println("Error executing query1:", err)
		return 0
	}
	if maxEpoch == nil {
		return 0
	}

	if val, ok := maxEpoch.(int); ok {
		return val
	} else {
		fmt.Println("Interface value is not an int")
		return 0
	}
}
