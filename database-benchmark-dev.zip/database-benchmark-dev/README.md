
# Database benchmarking

An easy-to-use and adaptable framework that supports the numerous functionalities of each database, this framework creates a clear log that includes time in many statistical parameters. 

```Go version: 1.22.1```\
```App version: 1.0.0```

### Download and set-up
```
step-1: Clone the repository.
git clone https://gitlab.com/netcorecloud/cee/database-benchmark.git

step-2: Navigate to the folder.
cd database-benchmark

step-3: Install the external modules and dependencies
go mod tidy

step-4: Create a folder named 'benchmark_logs' where logs will be generated
mkdir <path_to_logs>/benchmark_logs
```

### prerequisites prior to project execution 
* Create a .env file project folder and set-up the environment variables.\
    set-up connection string for the databases

    | Database name          | ENV variable name     | 
    |------------------------|-----------------------|
    | vertica                | VERTICA               |
    | local vertica          | LOCAL_VERTICA         |
    | provisioned redshift   | SERVERLESS_REDSHIFT   |
    | provisioned redshift   | PROVISIONED_REDSHIFT  |

* Add query files in the queries folder\
    To learn how to add a query, please refer to the section on query conventions specific to different databases.

### Steps to run the project
```
step-1: Build the project
go build .

step-2: Run the benchmarks
./benchmark [flags]

example 
./benchmark -f vertica_local_select.txt -d VERTICA_LOCAL -q select
```

### Flags
**General flags**
```
    -database    | -d  : name of the database same as in environment variable [required]
    -file_name   | -f  : name of the file containing queries [required]
    -ids         | -i  : Comma-separated list of integers indicating ids of queries to be run form the file [default whole file]
    -concurrency | -c  : indicates number of threads [default 1]
    -noq         | -n  : number of queries [default 1]
    -query       | -q  : type of query example select, insert etc. [required]
```
**Vertica and redshift specific flags**
```
    -file_names  | -fn : name of the file containing file_names which can be used to fetch data form S3 or other resource [default ""]
    -start             : epoch starting [default 0] 
    -end               : epoch ending [default INTMAX]
```

### Query conventions
**Vertica and Redshift**\
    ```<id>~<query_text>```\
    For example:\
        1\~select * from employee;\~
        2\~select name from employee where id=1