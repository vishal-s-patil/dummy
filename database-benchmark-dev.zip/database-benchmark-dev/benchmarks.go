package main

import (
	"benchmark/config"
	"benchmark/dbase"
	"benchmark/logs"
	"benchmark/utils"
	"flag"
	"fmt"
	"math"

	log "github.com/sirupsen/logrus"

	"github.com/joho/godotenv"
)

func init() {
	logs.OpenLog("benchmark_logs/dblog")

	err := godotenv.Load(".env")
	if err != nil {
		fmt.Printf("Error loading .env file: %v", err)
		log.Fatal("Error occured while loading env file: ", err)
	}
}

func main() {
	var database, file_name, ffile_name, idsStr, query string
	var concurrency, noq, start, end int
	var qids []int

	flag.StringVar(&database, "database", "", "database name")
	flag.StringVar(&file_name, "file_name", "", "name of file containing queries")
	flag.StringVar(&idsStr, "ids", "", "Comma-separated list of integers")
	flag.IntVar(&concurrency, "concurrency", 1, "concurrency")
	flag.IntVar(&noq, "noq", 1, "number of queries")
	flag.StringVar(&ffile_name, "file_names", "", "name of the file containing file_names")
	flag.StringVar(&query, "query", "", "name of function/query to call")
	flag.IntVar(&start, "start", 0, "name of function/query to call")
	flag.IntVar(&end, "end", math.MaxInt64, "name of function/query to call")

	flag.StringVar(&database, "d", "", "database name(shorthand)")
	flag.StringVar(&file_name, "f", "", "name of file containing queries(shorthand)")
	flag.StringVar(&idsStr, "i", "", "Comma-separated list of integers(shorthand)")
	flag.IntVar(&concurrency, "c", 1, "concurrency(shorthand)")
	flag.IntVar(&noq, "n", 1, "number of queries(shorthand)")
	flag.StringVar(&ffile_name, "fn", "", "name of the file containing file_names(shorthand)")
	flag.StringVar(&query, "q", "", "name of function/query to call(shorthand)")

	flag.Parse()

	config.Database_name = database

	qids, _ = utils.ParseIDs(idsStr)

	idQueryMap := make(map[int]string)

	utils.Retrive_query(file_name, idQueryMap, &qids)
	
	dbase.Connect()

	var err error

	switch query {
	case "select":
		err = dbase.Select(noq, concurrency, idQueryMap, qids, file_name)
	case "insert":
		err = dbase.Insert(idQueryMap)
	case "update":
		err = dbase.Update(noq, concurrency, idQueryMap, qids, file_name)
	case "delete":
		err = dbase.Delete(idQueryMap)
	case "unify":
		err = dbase.Unify(start, end, idQueryMap)
	case "merge":
		err = dbase.Merge(idQueryMap)
	case "unify_merge":
		err = dbase.Unify_merge(false, idQueryMap)
	case "copy":
		err = dbase.Copy(file_name, ffile_name, concurrency, idQueryMap)
	case "close":
		dbase.Close()
	default:
		fmt.Println("Please provide a valid function name")
	}

	if err != nil {
		log.Fatal("error occured in " + query + " function, terminating the application")
	}

	fmt.Println("closing the database")
	dbase.Close()
}
