package dbase

import (
	"benchmark/config"
	"benchmark/utils"
	"fmt"
	"math"
	"sort"
	"sync"
	"time"

	"github.com/google/uuid"
	log "github.com/sirupsen/logrus"
)

type Database interface {
	Connect() error
	Select(wg *sync.WaitGroup, workerID int, queryQueue <-chan int, idQueryMap map[int]string, bmid uuid.UUID, ts *[]int) error
	Insert() error
	Update(wg *sync.WaitGroup, workerID int, queryQueue <-chan int, idQueryMap map[int]string, bmid uuid.UUID, ts *[]int) error
	Delete() error
	Unify(start, end interface{}, query string) (time.Duration, int, error)
	Merge(query string) (time.Duration, int, error)
	Unify_merge(wg *sync.WaitGroup) error
	Copy(tid int, duration *[]time.Duration, ch chan string, wg *sync.WaitGroup, query string) error
	ExecuteQuery(id int, query string) (time.Duration, error)
	Close() error
}

var db Database

func Connect() {
	if config.Database_name == "VERTICA" || config.Database_name == "LOCAL_VERTICA" {
		db = &Vertica{}
	} else if config.Database_name == "SERVERLESS_REDSHIFT" || config.Database_name == "PROVISIONED_REDSHIFT" {
		db = &Redshift{}
	} else {
		log.Fatal("Please provide a valid database name as provided in docs")
	}

	err := db.Connect()

	if err != nil {
		log.Fatal("shutting down the application")
	}
}

func push_ids_to_channel(noq, concurrency int, idQueryMap map[int]string, queryIDs []int, file_name string) (uuid.UUID, chan int) {
	queryQueue := make(chan int, noq)

	portionCount := noq / len(idQueryMap)
	rem := noq % len(idQueryMap)

	bmid := uuid.New()

	initLog := fmt.Sprintf("[INIT]\t[bmid:%s]\t[sqlfile:%s]\t[args:{database:%s,concurrency:%d,noq:%d,qids:[%s]}]", bmid, file_name, config.Database_name, concurrency, noq, utils.IntegersToString(queryIDs, ","))

	log.Print(initLog)

	go func() {
		for j := 1; j <= len(queryIDs); j++ {
			for i := 1; i <= portionCount; i++ {
				queryQueue <- queryIDs[j-1]
			}
		}
		for j := 1; j <= rem && j <= len(queryIDs); j++ {
			queryQueue <- queryIDs[j-1]
		}
		close(queryQueue)
	}()

	return bmid, queryQueue
}

func calculate_stats(elapsed float64, concurrency int, bmid uuid.UUID, ts []int) {
	sort.Ints(ts)

	min := ts[0]
	max := ts[len(ts)-1]

	sum := 0

	for i := 0; i < len(ts); i++ {
		sum += ts[i]
	}

	mean := sum / len(ts)

	percent90 := ts[int(math.Round(float64(len(ts))*0.9))-1]
	percent99 := ts[int(math.Round(float64(len(ts))*0.99))-1]
	throughput := utils.SumOfArr(ts) / concurrency

	mp := map[string]interface{}{
		"bmid":       bmid,
		"min":        (time.Duration(min)).Seconds(),
		"max":        (time.Duration(max)).Seconds(),
		"mean":       (time.Duration(mean)).Seconds(),
		"percent90":  (time.Duration(percent90)).Seconds(),
		"percent99":  (time.Duration(percent99)).Seconds(),
		"throughput": (time.Duration(throughput)).Seconds(),
		"total_time": (elapsed),
	}

	endLog := fmt.Sprintf("[END]\t[bmid:%s]\t[total_time:%f]\t[stats:{min:%f,max:%f,mean:%f,90pc:%f,99pc:%f,throughput:%f}]", bmid, (elapsed), mp["min"], mp["max"], mp["mean"], mp["percent90"], mp["percent99"], mp["throughput"])

	fmt.Println(mp)

	log.Print(endLog)
}

func Select(noq, concurrency int, idQueryMap map[int]string, queryIDs []int, file_name string) error {
	var wg sync.WaitGroup

	bmid, queryQueue := push_ids_to_channel(noq, concurrency, idQueryMap, queryIDs, file_name)

	ts := []int{}
	start_time := time.Now()

	for i := 1; i <= concurrency; i++ {
		wg.Add(1)
		go db.Select(&wg, i, queryQueue, idQueryMap, bmid, &ts)
	}

	wg.Wait()

	elapsed := time.Since(start_time).Seconds()

	calculate_stats(elapsed, concurrency, bmid, ts)

	return nil
}

func Insert(idQueryMap map[int]string) error {
	return nil
}

func Update(noq, concurrency int, idQueryMap map[int]string, queryIDs []int, file_name string) error {
	var wg sync.WaitGroup

	bmid, queryQueue := push_ids_to_channel(noq, concurrency, idQueryMap, queryIDs, file_name)

	ts := []int{}
	start_time := time.Now()

	for i := 1; i <= concurrency; i++ {
		wg.Add(1)
		go db.Update(&wg, i, queryQueue, idQueryMap, bmid, &ts)
	}

	wg.Wait()

	elapsed := time.Since(start_time).Seconds()

	calculate_stats(elapsed, concurrency, bmid, ts)

	return nil
}

func Delete(idQueryMap map[int]string) error {
	return nil
}

func Unify(start, end int, idQueryMap map[int]string) error {
	db.Unify(start, end, idQueryMap[0])
	return nil
}

func Merge(idQueryMap map[int]string) error {
	db.Merge(idQueryMap[0])
	return nil
}

func Unify_merge(ts bool, idQueryMap map[int]string) error {
	durations := []time.Duration{}
	durations_unify := []time.Duration{}
	durations_merge := []time.Duration{}

	var prev interface{}
	var x interface{}

	if verticaDB, ok := db.(*Vertica); ok {
		if ts {
			prev = (time.Time{})
		} else {
			prev = 0
		}
		x, _ = verticaDB.GetMaxEpoch("crux_72994.tmp_userdetailsattrs", ts)
	} else if redshiftDB, ok := db.(*Redshift); ok {
		x, _ = redshiftDB.GetMaxEpoch("crux_72994.tmp_userdetailsattrs")
	}

	for { // prev != x || x == 0
		if x != 0 && prev != x {
			// if x != (time.Time{}) && prev != x {
			start_end := time.Now()

			elapsed, cnt, _ := db.Unify(prev, x, idQueryMap[0])
			durations_unify = append(durations_unify, elapsed)

			unifyLog := fmt.Sprintf("[UNIFY]\t[time:%s]\t[args{start:%d, end:%d, rows_inserted:%d}]", elapsed, prev, x, cnt)
			log.Print(unifyLog)

			elapsed, cnt, _ = db.Merge(idQueryMap[1])
			mergeLog := fmt.Sprintf("[UNIFY]\t[time:%s]\t[args{start:%d, end:%d, rows_inserted:%d}]", elapsed, prev, x, cnt)
			log.Print(mergeLog)

			elapsed = time.Since(start_end)

			durations = append(durations, elapsed)

			selectLog := fmt.Sprintf("[UNIFY_MERGE]\t[time:%s]\t]", elapsed)
			log.Print(selectLog)

			db.ExecuteQuery(0, "truncate table crux_72994.tmp2_userdetailsattrs")

			// fmt.Println("prev, x : ", prev, x)
		}

		prev = x
		x = GetMaxEpoch(ts)

		if x == 0 || x == nil {
			time.Sleep(1 * time.Minute)
			x = GetMaxEpoch(ts)
			if x == 0 || x == nil {
				if len(durations) != 0 {
					sort.Slice(durations, func(i, j int) bool {
						return durations[i] < durations[j]
					})

					min := durations[0]
					min_unify := durations_unify[0]
					min_merge := durations_unify[0]

					max := durations[len(durations)-1]
					max_unify := durations_unify[len(durations_unify)-1]
					max_merge := durations_unify[len(durations_unify)-1]

					var total, total_unify, total_merge time.Duration

					for _, duration := range durations {
						total += duration
						total_unify += duration
						total_merge += duration
					}
					avg := total / time.Duration(len(durations))
					avg_unify := total / time.Duration(len(durations_unify))
					avg_merge := total / time.Duration(len(durations_merge))

					endLog := fmt.Sprintf("[END:UNIFY_MERGE]\t[total_time:%s]\t[unify_total:%s]\t[merge_total:%s]\t[args:{min:%s, max:%s, avg:%s}]\t[args:{min:%s, max:%s, avg:%s]\t[args:{min:%s, max:%s, avg:%s]", total, total_unify, total_merge, min, max, avg, min_unify, max_unify, avg_unify, min_merge, max_merge, avg_merge)
					log.Print(endLog)
				}
				fmt.Println("terminating unify merge operation...")
				return nil
			}
		}
	}
}

func Copy(file_name, ffile_name string, not int, idQueryMap map[int]string) error {
	var wg sync.WaitGroup
	var durations []time.Duration

	ch := make(chan string, 100000)

	start_time := time.Now()
	for i := 0; i < not; i++ {
		wg.Add(1)
		go db.Copy(i, &durations, ch, &wg, idQueryMap[0])
	}

	utils.Insert_into_channel(ffile_name, ch)
	close(ch)

	wg.Wait()

	elapsed := time.Since(start_time)

	if len(durations) != 0 {
		sort.Slice(durations, func(i, j int) bool {
			return durations[i] < durations[j]
		})

		min := durations[0]

		max := durations[len(durations)-1]

		var total time.Duration
		for _, duration := range durations {
			total += duration
		}
		avg := total / time.Duration(len(durations))

		endLog := fmt.Sprintf("[END:COPY]\t[total_time:%s]\t[args:{min:%s, max:%s, avg:%s}]", elapsed, min, max, avg)
		log.Print(endLog)
	}

	return nil
}

func Close() {
	db.Close()
}

// helper functions
func GetMaxEpoch(ts bool) interface{} {
	var x interface{}

	if verticaDB, ok := db.(*Vertica); ok {
		x, _ = verticaDB.GetMaxEpoch("crux_72994.tmp_userdetailsattrs", ts)
	} else if redshiftDB, ok := db.(*Redshift); ok {
		x, _ = redshiftDB.GetMaxEpoch("crux_72994.tmp_userdetailsattrs")
	}

	return x
}
