package dbase

import (
	"benchmark/config"
	"benchmark/utils"
	"database/sql"
	"fmt"
	"os"
	"strconv"
	"sync"
	"time"

	"github.com/google/uuid"
	log "github.com/sirupsen/logrus"
	_ "github.com/vertica/vertica-sql-go"
)

type Vertica struct {
	Db_name string
	db      *sql.DB
}

func (p *Vertica) Connect() error {
	// connectionString := "vertica://dbadmin:@localhost:5433/mydb?sslmode=disable"

	connectionString := os.Getenv(config.Database_name)

	db, err := sql.Open("vertica", connectionString)

	if err != nil {
		// print("err : ", err)
		log.Error("Error connecting to database: ", err)
		return err
	}

	err = db.Ping()

	if err != nil {
		// print("error in vertica connection")
		log.Error("Error while pinging database: ", err)
		return err
	}

	fmt.Println(config.Database_name + " connection created...")

	p.db = db
	p.Db_name = "vertica"

	return nil
}

func (p *Vertica) ExecuteQuery(qid int, query string) (time.Duration, error) {
	start_time := time.Now()

	rows, err := p.db.Query(query)

	elapsed := time.Since(start_time)

	if err != nil {
		log.Error("Error executing query - " + strconv.Itoa(qid) + ": ", err)
		fmt.Println("error executing query: ", config.Database_name, err)
		return 0, err
	}

	columns, err := rows.Columns()
	if err != nil {
		log.Error("Error while getting number of columns: ", err)
		fmt.Println("error getting columns: ", config.Database_name, err)
		return 0, err
	}

	values := make([]interface{}, len(columns))
	for i := range values {
		var value interface{}
		values[i] = &value
	}

	// fmt.Println("Columns:", columns)

	for rows.Next() {
		err := rows.Scan(values...)
		if err != nil {
			log.Error("Error while scanning rows: ", err)
			fmt.Println("error scaning rows: ", config.Database_name, err)
			return 0, err
		}

		// for i, value := range values {
		// 	fmt.Printf("%s: %v\t", columns[i], *value.(*interface{}))
		// }
		// fmt.Println()
	}
	return elapsed, nil
}

func (p *Vertica) ExecuteQuery_DML(query string) (time.Duration, int, error) {
	start_time := time.Now()
	res, err := p.db.Exec(query)

	elapsed := time.Since(start_time)

	if err != nil {
		log.Error("Error executing DML query: ", err)
		fmt.Println("error executing query:ExecuteQuery_DML:", config.Database_name, err)
	}

	cnt, err := res.RowsAffected()

	if err != nil {
		log.Error("Error while getting rows affected: ", err)
		fmt.Println("error getting rows affected", config.Database_name, err)
	}

	return elapsed, int(cnt), nil
}

func (p *Vertica) Select(wg *sync.WaitGroup, workerID int, queryQueue <-chan int, idQueryMap map[int]string, bmid uuid.UUID, ts *[]int) error {
	if wg != nil {
		defer wg.Done()
	}
	var mutex sync.Mutex

	var error_count int
	var total_queries_executed int

	for query_id := range queryQueue {
		query := idQueryMap[query_id]

		elapsed, err := p.ExecuteQuery(query_id, query)

		if err != nil {
			error_count++
		}

		queryLog := fmt.Sprintf("[QUERY]\t[bmid:%s]\t[qid:%d]\t[tid:%d]\t[time:%s]", bmid, query_id, workerID, elapsed)

		mutex.Lock()
		*ts = append(*ts, int(elapsed))
		mutex.Unlock()

		log.Print(queryLog)
		total_queries_executed++
	}

	if error_count > 0 {
		endLog := fmt.Sprintf("[SELECT:FAILED_COUNT]\t[bmid:%s]\t[tid:%d]\t[success:%d]\t[failed:%d]", bmid, workerID, total_queries_executed-error_count, error_count)
		log.Error(endLog)
	}

	return nil
}

func (p *Vertica) Insert() error {
	return nil
}
func (p *Vertica) Update(wg *sync.WaitGroup, workerID int, queryQueue <-chan int, idQueryMap map[int]string, bmid uuid.UUID, ts *[]int) error {
	if wg != nil {
		defer wg.Done()
	}
	var mutex sync.Mutex

	for query_id := range queryQueue {
		query := idQueryMap[query_id]

		elapsed, _, _ := p.ExecuteQuery_DML(query)

		queryLog := fmt.Sprintf("[QUERY]\t[bmid:%s]\t[qid:%d]\t[tid:%d]\t[time:%s]", bmid, query_id, workerID, elapsed)

		mutex.Lock()
		*ts = append(*ts, int(elapsed))
		mutex.Unlock()

		log.Print(queryLog)
	}

	return nil
}
func (p *Vertica) Delete() error {
	return nil
}
func (p *Vertica) Unify(start, end interface{}, query string) (time.Duration, int, error) {
	// TODO: make changes for time.Time epoch_ts

	query = fmt.Sprintln(query, start, end)

	elapsed, rows, _ := p.ExecuteQuery_DML(query)

	return elapsed, rows, nil
}
func (p *Vertica) Merge(query string) (time.Duration, int, error) {
	elapsed, rows, _ := p.ExecuteQuery_DML(query)

	return elapsed, rows, nil
}
func (p *Vertica) Unify_merge(wg *sync.WaitGroup) error {
	defer wg.Done()

	return nil
}
func (p *Vertica) Copy(tid int, duration *[]time.Duration, ch chan string, wg *sync.WaitGroup, query string) error {
	defer wg.Done()

	for file_name := range ch {
		query = fmt.Sprintf(query, file_name)

		elapsed, _ := p.ExecuteQuery(1, query)

		queryLog := fmt.Sprintf("[COPY]\t[tid:%d]\t[time:%s]", tid, elapsed)
		*duration = append(*duration, elapsed)
		log.Print(queryLog)
	}

	return nil
}

func (p *Vertica) GetMaxEpoch(table_name string, ts bool) (interface{}, error) {
	var epoch interface{}
	if ts {
		q := fmt.Sprintf("SELECT MAX(epoch_ts) FROM %s;", table_name)
		epoch = utils.GetMaxEpoch_ts(q, p.db)
	} else {
		q := fmt.Sprintf("SELECT MAX(epoch) FROM %s;", table_name)
		epoch = utils.GetMaxEpoch(q, p.db)
	}
	return epoch, nil
}

func (p *Vertica) Close() error {
	p.db.Close()
	return nil
}
