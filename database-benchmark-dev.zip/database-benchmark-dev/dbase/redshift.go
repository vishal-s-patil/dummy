package dbase

import (
	"benchmark/config"
	"benchmark/utils"
	"database/sql"
	"fmt"
	"os"
	"sync"
	"time"

	"github.com/google/uuid"
	_ "github.com/lib/pq"
	log "github.com/sirupsen/logrus"
)

type Redshift struct {
	Db_name string
	db      *sql.DB
}

func (p *Redshift) Connect() error {
	// connectionString := "user=admin dbname=dev sslmode=require password=Netcor3VAdm1n host=vertica-redshift-test.880359164916.us-east-1.redshift-serverless.amazonaws.com port=5439"

	connectionString := os.Getenv(config.Database_name)

	db, err := sql.Open("postgres", connectionString)

	if err != nil {
		// print("err Connecting to database: ", config.Database_name, err)
		log.Error("Error connecting to database: ", err)
		return err
	}

	err = db.Ping()

	if err != nil {
		// print(err)
		log.Error("Error while pinging database: ", err)
		return err
	}

	fmt.Println(config.Database_name + " connection created...")

	p.db = db
	p.Db_name = "redshift"

	return nil
}
func (p *Redshift) Select(wg *sync.WaitGroup, workerID int, queryQueue <-chan int, idQueryMap map[int]string, bmid uuid.UUID, ts *[]int) error {
	if wg != nil {
		defer wg.Done()
	}
	var mutex sync.Mutex

	p.db.Query("SET enable_result_cache_for_session TO OFF;")

	for query_id := range queryQueue {
		query := idQueryMap[query_id]

		elapsed, _ := p.ExecuteQuery(query_id, query)

		queryLog := fmt.Sprintf("[QUERY]\t[bmid:%s]\t[qid:%d]\t[tid:%d]\t[time:%s]", bmid, query_id, workerID, elapsed)

		mutex.Lock()
		*ts = append(*ts, int(elapsed))
		mutex.Unlock()

		log.Print(queryLog)
	}

	return nil
}

func (p *Redshift) Insert() error {
	return nil
}
func (p *Redshift) Update(wg *sync.WaitGroup, workerID int, queryQueue <-chan int, idQueryMap map[int]string, bmid uuid.UUID, ts *[]int) error {
	return nil
}
func (p *Redshift) Delete() error {
	return nil
}
func (p *Redshift) Unify(start, end interface{}, query string) (time.Duration, int, error) {
	query = fmt.Sprintln(query, start, end)

	elapsed, rows, _ := p.ExecuteQuery_DML(query)

	return elapsed, rows, nil
}
func (p *Redshift) Merge(query string) (time.Duration, int, error) {
	elapsed, rows, _ := p.ExecuteQuery_DML(query)

	return elapsed, rows, nil
}
func (p *Redshift) Unify_merge(wg *sync.WaitGroup) error {
	defer wg.Done()

	return nil
}
func (p *Redshift) Copy(tid int, duration *[]time.Duration, ch chan string, wg *sync.WaitGroup, query string) error {
	defer wg.Done()

	for file_name := range ch {
		query = fmt.Sprintf(query, file_name)

		elapsed, _ := p.ExecuteQuery(1, query)

		queryLog := fmt.Sprintf("[COPY]\t[tid:%d]\t[time:%s]", tid, elapsed)
		*duration = append(*duration, elapsed)
		log.Print(queryLog)
	}

	return nil
}
func (p *Redshift) ExecuteQuery(id int, query string) (time.Duration, error) {
	start_time := time.Now()

	rows, err := p.db.Query(query)

	elapsed := time.Since(start_time)

	if err != nil {
		log.Error("Error executing query: ", err)
		fmt.Println(err)
	}

	columns, err := rows.Columns()
	if err != nil {
		log.Error("Error while getting number of columns: ", err)
		fmt.Println(err)
	}

	values := make([]interface{}, len(columns))
	for i := range values {
		var value interface{}
		values[i] = &value
	}

	// fmt.Println("Columns:", columns)

	for rows.Next() {
		err := rows.Scan(values...)
		if err != nil {
			log.Error("Error while scanning rows: ", err)
			fmt.Println(err)
		}

		// for i, value := range values {
		// 	fmt.Printf("%s: %v\t", columns[i], *value.(*interface{}))
		// }
		// fmt.Println()
	}
	return elapsed, nil
}

func (p *Redshift) ExecuteQuery_DML(query string) (time.Duration, int, error) {
	start_time := time.Now()

	res, err := p.db.Exec(query)

	elapsed := time.Since(start_time)

	if err != nil {
		log.Error("Error executing DML query: ", err)
		fmt.Println("error executing query:ExecuteQuery_DML:", err)
	}

	cnt, err := res.RowsAffected()

	if err != nil {
		log.Error("Error while getting rows affected: ", err)
		fmt.Println("error in copyResult.RowsAffected", err)
	}

	return elapsed, int(cnt), nil
}

func (p *Redshift) GetMaxEpoch(table_name string) (interface{}, error) {
	q := fmt.Sprintf("SELECT MAX(epoch_ts) FROM %s;", table_name)
	epoch := utils.GetMaxEpoch_ts(q, p.db)
	return epoch, nil
}

func (p *Redshift) Close() error {
	p.db.Close()
	return nil
}
