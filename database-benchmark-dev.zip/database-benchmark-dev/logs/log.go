package logs

import (
	"compress/gzip"
	"fmt"
	"io"
	"os"
	"time"
	rotatelogs "github.com/lestrrat-go/file-rotatelogs"
	log "github.com/sirupsen/logrus"
)

// LogFile log file path
//const LogFile = "/var/log/apps/sender/sender.log"

// LOGFILEMAXAGE ...
const LOGFILEMAXAGE = 60

// WriteLog log writer
func WriteLog(level string, UUID string, alert string, message interface{}) {
	msg := fmt.Sprintf("%v|%v: %+v", UUID, alert, message)
	if level == "ERROR" {
		log.Error(msg)
	} else {
		log.Info(msg)
	}
}

// WriteDebugLog log writer
func WriteDebugLog(alert string, message interface{}) {
	msg := fmt.Sprintf("%v: %+v", alert, message)
	log.Info(msg)
}

// LogFormatter log formatter structure
type LogFormatter struct {
	TimestampFormat string
	LevelDesc       []string
}

// Format format entry in custom format
func (f *LogFormatter) Format(entry *log.Entry) ([]byte, error) {
	timestamp := fmt.Sprintf(entry.Time.Format(f.TimestampFormat))
	// return []byte(fmt.Sprintf("%s|%s|%v|%s\n", timestamp, f.LevelDesc[entry.Level], os.Getpid(), entry.Message)), nil
	return []byte(fmt.Sprintf("%s\t%s\t%v\t%s\n", timestamp, f.LevelDesc[entry.Level], os.Getpid(), entry.Message)), nil
}

// OpenLog ...
func OpenLog(LogFile string) *rotatelogs.RotateLogs {

	fmt.Printf("Opening log file %s \n", LogFile)
	logFormatter := new(LogFormatter)
	logFormatter.TimestampFormat = "2006-01-02 15:04:05.000"
	logFormatter.LevelDesc = []string{"PANIC", "FATAL", "ERROR", "WARN", "INFO", "DEBUG", "TRACE"}
	log.SetFormatter(logFormatter)
	level, err := log.ParseLevel("INFO")
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	log.SetLevel(level)
	rl, rError := rotatelogs.New(
		LogFile+"%Y-%m-%d-%H.log",
		rotatelogs.WithLinkName(LogFile),
		rotatelogs.WithRotationTime(time.Minute),
		rotatelogs.WithMaxAge(time.Duration(LOGFILEMAXAGE)*24*time.Hour),
		rotatelogs.WithHandler(rotatelogs.HandlerFunc(func(e rotatelogs.Event) {
			if e.Type() != rotatelogs.FileRotatedEventType {
				return
			}
			compressPreviousFile(e.(*rotatelogs.FileRotatedEvent).PreviousFile())
		})),
	)
	if rError != nil {
		fmt.Println(rError)
		os.Exit(1)
	}
	log.SetOutput(rl)
	return rl
}
func compressPreviousFile(fileName string) {
	compressLogFile(fileName, fileName+".gz")
}
func compressLogFile(src, dst string) (err error) {
	f, err := os.Open(src)
	if err != nil {
		return fmt.Errorf("failed to open log file: %v", err)
	}
	defer f.Close()
	fi, err := os.Stat(src)
	if err != nil {
		return fmt.Errorf("failed to stat log file: %v", err)
	}
	if err := chown(dst, fi); err != nil {
		return fmt.Errorf("failed to chown compressed log file: %v", err)
	}
	// If this file already exists, we presume it was created by
	// a previous attempt to compress the log file.
	gzf, err := os.OpenFile(dst, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, fi.Mode())
	if err != nil {
		return fmt.Errorf("failed to open compressed log file: %v", err)
	}
	defer gzf.Close()
	gz := gzip.NewWriter(gzf)
	defer func() {
		if err != nil {
			os.Remove(dst)
			err = fmt.Errorf("failed to compress log file: %v", err)
		}
	}()
	if _, err := io.Copy(gz, f); err != nil {
		return err
	}
	if err := gz.Close(); err != nil {
		return err
	}
	if err := gzf.Close(); err != nil {
		return err
	}
	if err := f.Close(); err != nil {
		return err
	}
	if err := os.Remove(src); err != nil {
		return err
	}
	return nil
}
func chown(_ string, _ os.FileInfo) error {
	return nil
}