package config

var Database_name string;